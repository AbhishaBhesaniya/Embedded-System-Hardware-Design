Readme.txt file for the Manufacturing directory.

Student Names:
Student Numbers:
Phone Contact Information:
Board Size:
